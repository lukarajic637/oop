#include "Player.h"
#include "Enemy.h"

Player::Player(const std::string& name, int health, int score)
	: GameCharacter(name, health), score(score) {}

Player::~Player() {}

void Player::addScore(int amount) {
	score += amount;
}

int Player::getScore() const {
	return score;
}