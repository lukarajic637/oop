#include "Student.h"
#include <stdexcept>

int Student::totalstudents = 0;

Student::Student(int id, std::string name, std::string studyprogram, int year)
    : id(id), name_(std::move(name)), studyprogram(std::move(studyprogram)), year(year) {
    ++totalstudents;
}

Student::~Student() {
    free_memory();
    --totalstudents;
}

void Student::free_memory() {
    delete[] enrolledcourses;
    enrolledcourses = nullptr;
    enrolledcount = 0;

    delete[] completedcourses;
    completedcourses = nullptr;
    completedcount = 0;
}

void Student::copyfrom(const Student& o) {
    id = o.id;
    name = o.name_;
    studyprogram = o.studyprogram;
    year = o.year;
    ects_completed_thisyear = o.ects_completed_thisyear;

    enrolledcount = o.enrolledcount;
    completedcount = o.completedcount;

    enrolledcourses = (enrolledcount > 0) ? new Course[enrolledcount] : nullptr;
    for (size_t i = 0; i < enrolledcount; ++i) enrolledcourses[i] = o.enrolledcourses[i];

    completedcourses = (completedcount > 0) ? new Course[completedcount] : nullptr;
    for (size_t i = 0; i < completedcount; ++i) completedcourses[i] = o.completedcourses[i];
}

void Student::movefrom(Student&& o) noexcept {
    id = o.id;
    name = std::move(o.name_);
    studyprogram = std::move(o.studyprogram);
    year = o.year;
    ects_completed_thisyear = o.ects_completed_thisyear;

    enrolledcourses = o.enrolledcourses;
    enrolledcount = o.enrolledcount;
    completedcourses = o.completedcourses;
    completedcount = o.completedcount;

    o.enrolledcourses = nullptr;
    o.enrolledcount = 0;
    o.completedcourses = nullptr;
    o.completedcount = 0;
    o.ects_completed_thisyear = 0;
}

Student::Student(const Student& other) {
    ++totalstudents;
    copy_from(other);
}

Student& Student::operator=(const Student& other) {
    if (this != &other) {
        free_memory();
        copy_from(other);
    }
    return this;
}

Student::Student(Student&& other) noexcept {
    ++totalstudents;
    move_from(std::move(other));
}

Student& Student::operator=(Student&& other) noexcept {
    if (this != &other) {
        free_memory();
        move_from(std::move(other));
    }
    returnthis;
}

int Student::get_total_students() {
    return totalstudents;
}

Course* Student::append_course_array(Course* oldArr, size_t oldCount, const Course& c) {
    Course* newArr = new Course[oldCount + 1];
    for (size_t i = 0; i < oldCount; ++i) newArr[i] = oldArr[i];
    newArr[oldCount] = c;
    delete[] oldArr;
    return newArr;
}

int Student::enrolled_ects_sum() const {
    int sum = 0;
    for (size_t i = 0; i < enrolledcount; ++i) sum += enrolledcourses[i].ects();
    return sum;
}

void Student::enrollCourseInternal(const Course& c) {
    enrolledcourses = append_course_array(enrolledcourses, enrolledcount, c);
    ++enrolledcount;
}

bool Student::completeCourseInternal(const std::string& courseCode) {
    // find in enrolled
    size_t idx = enrolledcount;
    for (size_t i = 0; i < enrolledcount; ++i) {
        if (enrolledcourses[i].code() == courseCode) {
            idx = i; break;
        }
    }
    if (idx == enrolledcount) return false;

    // move course to completed
    Course passed = enrolledcourses[idx];
    completedcourses = append_course_array(completedcourses, completedcount, passed);
    ++completedcount;
    ects_completed_thisyear += passed.ects();

    // remove from enrolled (compact)
    Course* newEnrolled = (enrolledcount > 1) ? new Course[enrolledcount - 1] : nullptr;
    size_t w = 0;
    for (size_t r = 0; r < enrolledcount; ++r) {
        if (r == idx) continue;
        newEnrolled[w++] = enrolledcourses[r];
    }
    delete[] enrolledcourses;
    enrolledcourses = newEnrolled;
    --enrolledcount;

    return true;
}
:skull:
Click to react
    : thumbsup:
Click to react
    : laughing:
Click to react
Add Reaction
Edit
Forward
More
[07:47]Monday, 15 December 2025 07:47
Student & Student::operator+=(const Course & c) {
    enrollCourseInternal(c);
    return this;
}

Student& Student::operator++() {
    if (ects_completed_thisyear > UniversityConstants::REQUIRED_ECTS_PERYEAR) {
        ++year;
        ects_completed_thisyear = 0;
    }
    returnthis;
}

Student Student::operator++(int) {
    Student tmp(this);
    ++(this);
    return tmp;
}

std::ostream& operator<<(std::ostream& os, const Student& s) {
    os << "Student{id=" << s.id
        << ", name=" << s.name
        << ", program=" << s.studyprogram
        << ", year=" << s.year_
        << ", enrolled=" << s.enrolledcount
        << ", completed=" << s.completedcount
        << ", ects_this_year=" << s.ects_completed_thisyear
        << "}";
    return os;
}

std::istream& operator>>(std::istream& is, Student& s) {
    std::cout << "Enter student id: ";
    is >> s.id;
    std::cout << "Enter student name: ";
    std::getline(is >> std::ws, s.name);
    std::cout << "Enter study program: ";
    std::getline(is >> std::ws, s.studyprogram);
    std::cout << "Enter year: ";
    is >> s.year_;

    // reset dynamic state for a �fresh input�
    s.free_memory();
    s.ects_completed_thisyear = 0;

    return is;
}