
#pragma once
#include <vector>
#include <string>
#include "Student.h"
#include "Course.h"

class StudentOffice {
public:
    static void moveStudent(Student& s, std::string new_program);

    static bool enroll_student(Student& s, const Course& c);

    static bool process_exam_results(Student& s, const std::string& courseCode);

    static void update_student_years(std::vector<Student>& students);
};