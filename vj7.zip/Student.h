#pragma once
#include <string>
#include <iostream>
#include <utility>
#include "Course.h"
#include "UniversityConstants.h"

class StudentOffice; // forward

class Student {
private:
    int id{ 0 };
    std::string name;
    std::string studyprogram;
    int year_{ 1 };

    Course* enrolledcourses{ nullptr };
    size_t enrolledcount{ 0 };

    Course* completedcourses{ nullptr };
    size_t completedcount{ 0 };

    int ects_completed_thisyear{ 0 };

    static int totalstudents;

    void free_memory();
    void copy_from(const Student& other);
    void move_from(Student&& other) noexcept;

    static Course* append_course_array(Course* oldArr, size_t oldCount, const Course& c);

    int enrolled_ects_sum() const;

public:
    Student(int id, std::string name, std::string study_program, int year);

    // Rule of Five
    ~Student();
    Student(const Student& other);
    Student& operator=(const Student& other);
    Student(Student&& other) noexcept;
    Student& operator=(Student&& other) noexcept;

    // statics
    static int get_totalstudents();

    // getters
    int id() const { return id; }
    const std::string& name() const { return name_; }
    const std::string& study_program() const { return studyprogram; }
    int year() const { return year_; }

    size_t enrolled_count() const { return enrolledcount; }
    size_t completed_count() const { return completedcount; }
    int ects_completed_this_year() const { return ects_completed_thisyear; }

    // student actions
    void enrollCourseInternal(const Course& c);      // used by StudentOffice
    bool completeCourseInternal(const std::string& courseCode); // used by StudentOffice

    // operators
    Student& operator+=(const Course& c); // add to enrolled
    Student& operator++();                // prefix
    Student operator++(int);              // postfix

    friend std::ostream& operator<<(std::ostream& os, const Student& s);
    friend std::istream& operator>>(std::istream& is, Student& s);

    friend class StudentOffice;
};#pragma once
