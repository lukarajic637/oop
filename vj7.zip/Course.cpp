#include "Course.h"

Course::Course(std::string name, std::string code, int ects)
    : name(std::move(name)), code(std::move(code)), ects(ects) {
}

std::ostream& operator<<(std::ostream& os, const Course& c) {
    os << "Course{name=" << c.name << ", code=" << c.code << ", ects=" << c.ects << "}";
    return os;
}

std::istream& operator>>(std::istream& is, Course& c) {
    std::cout << "Enter course name: ";
    std::getline(is >> std::ws, c.name);
    std::cout << "Enter course code: ";
    std::getline(is >> std::ws, c.code);
    std::cout << "Enter ECTS: ";
    is >> c.ects_;
    return is;
}