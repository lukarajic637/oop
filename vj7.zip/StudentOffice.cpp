#include "StudentOffice.h"
#include "UniversityConstants.h"
#include <iostream>
#include <utility>

void StudentOffice::moveStudent(Student& s, std::string new_program) {
    // explicit move semantics
    s.studyprogram = std::move(new_program);
}

bool StudentOffice::enroll_student(Student& s, const Course& c) {
    int ects_now = 0;
    for (size_t i = 0; i < s.enrolledcount; ++i) ects_now += s.enrolledcourses[i].ects();

    if (ects_now + c.ects() > UniversityConstants::MAX_ETCS_PER_YEAR) {
        return false;
    }
    s.enrollCourseInternal(c);
    return true;
}

bool StudentOffice::process_exam_results(Student& s, const std::string& courseCode) {
    return s.completeCourseInternal(courseCode);
}

void StudentOffice::update_student_years(std::vector<Student>& students) {
    for (auto& s : students) {
        ++s; // uses operator++ rules
    }
}