#include <iostream>
#include <vector>
#include "Student.h"
#include "Course.h"
#include "StudentOffice.h"
#include "UniversityConstants.h"

int main() {
    UniversityConstants::print_university_rules();

    std::vector<Student> students;
    int n;
    std::cout << "How many students? ";
    std::cin >> n;

    for (int i = 0; i < n; ++i) {
        Student s(0, "", "", 1);
        std::cin >> s;
        students.push_back(std::move(s));
    }

    std::cout << "\nAll students:\n";
    for (const auto& s : students) std::cout << s << "\n";

    std::cout << "\nTotal students (static): " << Student::get_total_students() << "\n";

    Course c1("Mathematics 1", "MATH1", 5);
    Course c2("Programming 1", "PROG1", 5);
    Course c3("Databases", "DB1", 5);

    if (!students.empty()) {
        auto& s = students[0];

        std::cout << "\nEnrolling courses for: " << s.name() << "\n";
        std::cout << "Enroll MATH1: " << (StudentOffice::enroll_student(s, c1) ? "OK" : "FAIL") << "\n";
        std::cout << "Enroll PROG1: " << (StudentOffice::enroll_student(s, c2) ? "OK" : "FAIL") << "\n";
        std::cout << "Enroll DB1: " << (StudentOffice::enroll_student(s, c3) ? "OK" : "FAIL") << "\n";
        std::cout << s << "\n";

        std::cout << "\nProcessing exam results:\n";
        std::cout << "Pass PROG1: " << (StudentOffice::process_exam_results(s, "PROG1") ? "OK" : "FAIL") << "\n";
        std::cout << "Pass MATH1: " << (StudentOffice::process_exam_results(s, "MATH1") ? "OK" : "FAIL") << "\n";
        std::cout << s << "\n";

        // Add more passed courses to trigger year increment
        for (int i = 0; i < 10; ++i) {
            Course cx("Dummy", "D" + std::to_string(i), 5);
            StudentOffice::enroll_student(s, cx);
            StudentOffice::process_exam_results(s, cx.code());
        }
        std::cout << "\nBefore year update: " << s << "\n";

        StudentOffice::update_student_years(students);
        std::cout << "After year update:  " << students[0] << "\n";
    }

    std::cout << "\nTotal students at end: " << Student::get_total_students() << "\n";
    return 0;
}