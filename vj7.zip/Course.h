#pragma once
#include <string>
#include <iostream>

class Course {
private:
    std::string name;
    std::string code;
    int ects{ 0 };

public:
    Course() = default;
    Course(std::string name, std::string code, int ects);

    const std::string& name() const { return name; }
    const std::string& code() const { return code; }
    int ects() const { return ects; }

    friend std::ostream& operator<<(std::ostream& os, const Course& c);
    friend std::istream& operator>>(std::istream& is, Course& c);
};