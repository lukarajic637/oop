#ifndef ANIMAL_H
#define ANIMAL_H

#include<string>
#include<stdexcept>

using namespace std;

class Animal{
protected:
	string ime;
	int hrana;
	string vrsta;
	Animal(string ime, string vrsta, int hrana);
public:
	virtual ~Animal() = default;

	virtual string getSpecies() const = 0;
	virtual double getDailyFood() const = 0;
	virtual string getName() const = 0;

}
#endif
