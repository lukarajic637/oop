#include "Animal.h"

Animal::Animal(std::string ime, int hrana, std::string vrsta)
	:ime(ime), hrana(hrana), vrsta(vrsta) {
	if (name.empty)
}